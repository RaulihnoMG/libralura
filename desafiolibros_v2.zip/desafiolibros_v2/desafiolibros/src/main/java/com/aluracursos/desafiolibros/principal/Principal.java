package com.aluracursos.desafiolibros.principal;

import com.aluracursos.desafiolibros.model.*;
import com.aluracursos.desafiolibros.repository.LibroRepository;
import com.aluracursos.desafiolibros.service.ConsumoAPI;
import com.aluracursos.desafiolibros.service.ConvierteDatos;

import java.util.*;

public class Principal {
    private static final String URL_Base = "https://gutendex.com/books/";
    private ConsumoAPI consumoAPI = new ConsumoAPI();
    private ConvierteDatos conversor = new ConvierteDatos();
    private Scanner teclado = new Scanner(System.in);
    private LibroRepository repositorio;
    private List<Libros> librosGuardados;
    private List<Autor> autoresRegistrados;

    public Principal(LibroRepository repository) {
        this.repositorio = repository;
    }

    public void muestraElMenu (){
        var opcion = -1;
        while (opcion != 0) {
            var menu = """
                        1 - Buscar Libro por Titulo
                        2 - Mostrar Libros registrado
                        3 - Mostrar Autores Registrados
                        4 - Mostrar Autores vivos en un determinado año
                        5 - Mostrar libros por idioma

                        0 - Salir
                        """;
            System.out.println(menu);
            opcion = teclado.nextInt();
            teclado.nextLine();

            switch (opcion) {
                case 1:
                    getDatosLibros();
                    break;
                case 2:
                    mostrarLibros();
                    break;
                case 3:
                    autoresEnDB();
                    break;
                case 4:
                    autoresVivos();
                    break;
                case 5:
                    librosPorIdioma();
                    break;


                case 0:
                    System.out.println("Cerrando la aplicación...");
                    break;
                default:
                    System.out.println("Opción inválida");
            }
        }

//        var json = consumoAPI.obtenerDatos(URL_Base);
//        System.out.println(json);
//        var datos = conversor.obtenerDatos(json, DatosGenerales.class);
//        System.out.println(datos);
//
//        //Top 10 descargas
//        System.out.println("Top 10 descargas");
//        datos.libros().stream()
//                .sorted(Comparator.comparing(DatosLibros::numeroDeDescargas).reversed())
//                .limit(10)
//                .map(l -> l.titulo().toUpperCase())
//                .forEach(System.out::println);
//
//        //Busqueda de libro
//        System.out.println("Ingrese el nombre del libro: ");
//        var tituloLibro = teclado.nextLine();
//        json = consumoAPI.obtenerDatos(URL_Base + "?search="+tituloLibro.replace(" ", "+"));
//        var datosBusqueda = conversor.obtenerDatos(json,DatosGenerales.class);
//        Optional<DatosLibros> libroBuscado = datosBusqueda.libros().stream()
//                .filter(l -> l.titulo().toUpperCase().contains(tituloLibro.toUpperCase()))
//                .findFirst();
//        if(libroBuscado.isPresent()){
//            System.out.println("Libro encontrado: ");
//            System.out.println(libroBuscado.get());
//        }else {
//            System.out.println("Libro NO encontrado");
//        }
//
//        //trabajando con estadisticas
//        DoubleSummaryStatistics est = datos.libros().stream()
//                .filter(d -> d.numeroDeDescargas()>0)
//                .collect(Collectors.summarizingDouble(DatosLibros::numeroDeDescargas));
//        System.out.println("Cantidad Media de Descargas");
//        System.out.println(est.getAverage());
//        System.out.println("Cantidad max de descargas");
//        System.out.println(est.getMax());
    }

    private DatosLibros getDatosLibros() {
        System.out.println("Ingrese el nombre del libro: ");
        var anoElegido = teclado.nextInt();
        var json = consumoAPI.obtenerDatos("https://gutendex.com/books" + "?author_year_start="+ (anoElegido-1) +"&author_year_end="+(anoElegido+1));
        DatosGenerales datosBusqueda = conversor.obtenerDatos(json,DatosGenerales.class);
        Optional<DatosLibros> libroBuscado = datosBusqueda.libros().stream().findAny();
        if(libroBuscado.isPresent()){
            System.out.println("Lista de Libros: ");
            System.out.println(libroBuscado.get());
            Libros libros = new Libros(libroBuscado.get());
        }else {
            System.out.println("Libros NO encontrados");
        }
        return null;
//        Libros libros = new Libros(libroBuscado);
//        System.out.println(libros);
//        repositorio.save(libros);
//        return datosBusqueda;
    }

    private void mostrarLibros(){
        librosGuardados =repositorio.findAll();
        librosGuardados.stream()
                .forEach(System.out::println);
    }

    private void autoresEnDB(){
        librosGuardados =repositorio.findAll();
        librosGuardados.stream()
                .forEach(System.out::println);
    }

    private void autoresVivos(){
        System.out.println("Ingrese el año");
        var tituloLibro = teclado.nextLine();
        var json = consumoAPI.obtenerDatos(URL_Base + "?search="+tituloLibro.replace(" ", "+"));
        DatosGenerales datosBusqueda = conversor.obtenerDatos(json,DatosGenerales.class);
        Optional<DatosLibros> libroBuscado = datosBusqueda.libros().stream()
                .filter(l -> l.titulo().toUpperCase().contains(tituloLibro.toUpperCase()))
                .findFirst();
        if(libroBuscado.isPresent()){
            System.out.println("Libro encontrado: ");
            System.out.println(libroBuscado.get());
            Libros libros = new Libros(libroBuscado.get());
            List<DatosAutor> datosAutor = new ArrayList<>();
            DatosAutor datAut2 = conversor.obtenerDatos(json, DatosAutor.class);
            datosAutor.add(datAut2);
            Autor autors = new Autor(datosAutor);
            repositorio.save(libros);
        }else {
            System.out.println("Libro NO encontrado");
        }
    }

    private void librosPorIdioma(){
        System.out.println("Ingrese el idioma: (en, fr, es, br)");
        var idioma = teclado.nextLine();
        var json = consumoAPI.obtenerDatos("https://gutendex.com/books" + "?languages="+ idioma);
        DatosGenerales datosBusqueda = conversor.obtenerDatos(json,DatosGenerales.class);
        Optional<DatosLibros> libroBuscado = datosBusqueda.libros().stream().findFirst();
        if(libroBuscado.isPresent()){
            System.out.println("Lista de Libros: ");
            System.out.println(libroBuscado.get());
            Libros libros = new Libros(libroBuscado.get());
        }else {
            System.out.println("Libros NO encontrados");
        }

    }
}
