package com.aluracursos.desafiolibros.repository;

import com.aluracursos.desafiolibros.model.Libros;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LibroRepository extends JpaRepository<Libros, Long> {
}
